# Step-by-Step Project Guide
## AI Tool / Prompt Usage Analytics

### Step 1 — Define the problem
**Problem statement:** Organizations and learners use multiple AI tools for different tasks, but may not know which use cases are most common, what prompt patterns are associated with better outcomes, how long responses take, or how much usage costs.

**Objectives**
1. Measure AI usage across tools, dates, user types, and departments.
2. Compare use cases and prompt categories.
3. Examine task success and satisfaction.
4. Identify patterns in prompt length, retries, response time, and estimated cost.
5. Build a dashboard and propose practical recommendations.

### Step 2 — Understand the dataset
Open `ai_tool_prompt_usage_dataset.csv`. Review the columns in `data_dictionary.md`.
- Each row represents one simulated AI session.
- `task_success` is binary: 1 = successful, 0 = unsuccessful.
- `satisfaction_rating` ranges from 1 to 5.
- `estimated_cost_usd` is illustrative only.

### Step 3 — Prepare and clean the data
In Excel/Power Query/Python:
1. Check row count and column names.
2. Check duplicate `session_id` values.
3. Check missing values.
4. Ensure `session_date` is a date and numerical columns are numeric.
5. Check ranges: success is 0/1, rating is 1–5, retries are non-negative.
6. Do not remove valid outliers automatically; inspect them first.
7. Record any cleaning decisions in your report.

### Step 4 — Create calculated metrics
Calculate:
- Total sessions
- Number of distinct AI tools
- Task success rate = average of `task_success` × 100
- Average satisfaction rating
- Average response time
- Total estimated cost
- Average prompt word count
- Retry rate = sessions with `retry_count > 0` / all sessions × 100
- Cost per successful session = total estimated cost / successful sessions

### Step 5 — Perform exploratory data analysis (EDA)
Answer questions such as:
1. Which AI tool has the most sessions?
2. Which use cases are most common?
3. Which prompt categories have the highest success rate?
4. Which tool has the shortest average response time?
5. Does retry count appear associated with satisfaction?
6. Do prompt lengths differ across use cases?
7. Which departments have the highest usage?
8. Which use cases account for the largest estimated cost?
9. How does usage change by month?
10. Which groups have both high success and high satisfaction?

**Caution:** Comparisons are descriptive, not proof that a tool or prompt style caused an outcome. This synthetic dataset is for demonstrating analysis methods.

### Step 6 — Build charts
Recommended charts:
1. KPI cards: sessions, success rate, satisfaction, response time, estimated cost.
2. Bar chart: sessions by AI tool.
3. Bar chart: sessions by use case.
4. Clustered bar chart: success rate by prompt category.
5. Bar chart: average response time by tool.
6. Line chart: sessions by month.
7. Scatter plot: prompt word count vs. satisfaction or success.
8. Bar chart: estimated cost by use case.
9. Heatmap/matrix: tool by use case, with session count or success rate.

### Step 7 — Build a Power BI / Tableau dashboard
Suggested layout:
- Top row: KPI cards.
- Left: filters for date, AI tool, use case, department, user type.
- Middle: usage by tool and use case.
- Bottom: success/satisfaction, response time, and cost.
- Add clear chart titles, units, and data source note: “Synthetic learning dataset; cost values are illustrative.”

### Step 8 — Generate insights
Use evidence from your actual charts. Write 4–6 insights in this format:
- **Observation:** What the chart shows.
- **Evidence:** The value or comparison supporting it.
- **Implication:** Why it matters.
- **Recommendation:** What action you suggest.

Avoid inventing findings before analyzing the dataset.

### Step 9 — Recommendations
Possible recommendation areas, depending on your results:
- Create prompt-writing guidance for low-success use cases.
- Review tasks with high retry counts.
- Investigate slow response categories.
- Monitor estimated cost per successful session.
- Collect real, consented, privacy-safe usage logs before making operational decisions.

### Step 10 — Final report structure
1. Cover page
2. Abstract / executive summary
3. Introduction and problem statement
4. Objectives and scope
5. Dataset description and limitations
6. Data cleaning and preparation
7. Methodology and KPI definitions
8. EDA charts and observations
9. Dashboard screenshots
10. Findings and recommendations
11. Limitations and ethical considerations
12. Conclusion
13. Appendix: AI prompts and code

### Step 11 — Final checklist
- [ ] Dataset file opens correctly
- [ ] Data types and missing values checked
- [ ] Metrics use clear definitions
- [ ] Charts have titles and units
- [ ] Insights match computed results
- [ ] Synthetic data is clearly disclosed
- [ ] Cost is described as illustrative
- [ ] Dashboard filters work
- [ ] Report includes limitations and recommendations
