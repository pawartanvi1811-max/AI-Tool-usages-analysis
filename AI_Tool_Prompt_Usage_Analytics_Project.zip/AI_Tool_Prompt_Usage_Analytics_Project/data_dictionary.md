# Data Dictionary — AI Tool / Prompt Usage Analytics

## Dataset overview
- File: `ai_tool_prompt_usage_dataset.csv`
- Rows: 1,200 simulated AI usage sessions
- Purpose: Practice descriptive analytics, prompt performance analysis, cost analysis, and dashboard development.
- Important: This is synthetic data generated for a learning project. It is not real user telemetry and does not represent actual vendor prices or model performance.

## Column definitions
| Column | Type | Meaning |
|---|---|---|
| session_id | Text | Unique identifier for one AI usage session |
| session_date | Date | Date of the session |
| user_type | Category | Broad user role (e.g., Student, Developer) |
| department | Category | Department or functional area |
| ai_tool | Category | AI tool used in the session |
| model_name | Category | Generic model label used for comparison |
| use_case | Category | Main task type |
| prompt_category | Category | Prompt structure or intent |
| prompt_word_count | Integer | Number of words in the user prompt |
| response_word_count | Integer | Number of words in the generated response |
| input_tokens | Integer | Simulated input-token count |
| output_tokens | Integer | Simulated output-token count |
| response_time_seconds | Decimal | Simulated response latency in seconds |
| retry_count | Integer | Number of additional attempts in the session |
| task_success | Integer (0/1) | Whether the task was marked successful |
| satisfaction_rating | Integer (1–5) | Simulated user satisfaction rating |
| feedback_type | Category | Simplified feedback label |
| estimated_cost_usd | Decimal | Illustrative estimated cost; not actual vendor pricing |

## Suggested derived metrics
- Total sessions = row count
- Successful sessions = sum of `task_success`
- Task success rate = mean of `task_success` × 100
- Average satisfaction = mean of `satisfaction_rating`
- Average response time = mean of `response_time_seconds`
- Total estimated cost = sum of `estimated_cost_usd`
- Cost per successful session = total estimated cost / successful sessions
- Retry rate = percentage of sessions where `retry_count` > 0
- Average prompt length = mean of `prompt_word_count`
