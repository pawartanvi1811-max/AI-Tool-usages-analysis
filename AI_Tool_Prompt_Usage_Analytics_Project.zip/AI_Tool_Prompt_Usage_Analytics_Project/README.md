# AI Tool / Prompt Usage Analytics Project

## 1. Project objective
Analyze simulated AI usage sessions to understand adoption, common use cases, prompt patterns, response speed, task success, satisfaction, retries, and estimated cost.

## 2. Files included
- `ai_tool_prompt_usage_dataset.csv` — main dataset (1,200 rows)
- `data_dictionary.md` — column descriptions and metric definitions
- `step_by_step_project_guide.md` — project workflow and report structure
- `starter_analysis.py` — Python starter analysis that outputs summary CSVs
- `ai_prompt_templates.md` — prompts to use with an AI assistant during the project

## 3. Important dataset note
The data is synthetic and designed for practice. Do not describe the results as real-world findings. Cost figures are illustrative and are not real vendor pricing.

## 4. Suggested tools
Beginner: Excel or Google Sheets.
Dashboard: Power BI or Tableau.
Optional coding: Python with pandas and matplotlib.

## 5. Quick start
1. Extract the ZIP.
2. Open the CSV in Excel/Google Sheets, or place all files in one folder.
3. Follow the guide in `step_by_step_project_guide.md`.
4. If using Python, run: `python starter_analysis.py`
5. Use the output summary CSVs to build charts and write findings.
