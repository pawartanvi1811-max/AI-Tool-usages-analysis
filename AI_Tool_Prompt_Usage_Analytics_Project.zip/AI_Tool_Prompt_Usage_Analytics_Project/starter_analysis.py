"""Starter script for AI Tool / Prompt Usage Analytics.
Requires: pandas, matplotlib. Install with: pip install pandas matplotlib
Run from the folder containing this script and the dataset.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
DATA = BASE / "ai_tool_prompt_usage_dataset.csv"
OUT = BASE / "analysis_outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["session_date"])

# Basic validation
print("Rows, columns:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nDuplicate session IDs:", df["session_id"].duplicated().sum())
print("\nNumeric summary:\n", df.describe(numeric_only=True).round(2))

# Overall KPIs
kpis = pd.DataFrame([{
    "total_sessions": len(df),
    "distinct_tools": df["ai_tool"].nunique(),
    "task_success_rate_pct": round(df["task_success"].mean() * 100, 2),
    "average_satisfaction": round(df["satisfaction_rating"].mean(), 2),
    "average_response_time_seconds": round(df["response_time_seconds"].mean(), 2),
    "total_estimated_cost_usd": round(df["estimated_cost_usd"].sum(), 4),
    "average_prompt_word_count": round(df["prompt_word_count"].mean(), 2),
    "retry_rate_pct": round((df["retry_count"] > 0).mean() * 100, 2),
    "cost_per_successful_session_usd": round(
        df["estimated_cost_usd"].sum() / max(df["task_success"].sum(), 1), 5
    )
}])
kpis.to_csv(OUT / "overall_kpis.csv", index=False)
print("\nOverall KPIs:\n", kpis.T)

# Grouped summaries
for col in ["ai_tool", "use_case", "prompt_category", "department", "user_type", "model_name"]:
    summary = df.groupby(col, dropna=False).agg(
        sessions=("session_id", "count"),
        success_rate_pct=("task_success", lambda x: x.mean() * 100),
        average_satisfaction=("satisfaction_rating", "mean"),
        average_response_time_seconds=("response_time_seconds", "mean"),
        average_prompt_words=("prompt_word_count", "mean"),
        estimated_cost_usd=("estimated_cost_usd", "sum"),
        retry_rate_pct=("retry_count", lambda x: (x > 0).mean() * 100),
    ).round(2).reset_index()
    summary.to_csv(OUT / f"summary_by_{col}.csv", index=False)

# Monthly usage
df["month"] = df["session_date"].dt.to_period("M").astype(str)
monthly = df.groupby("month").agg(
    sessions=("session_id", "count"),
    success_rate_pct=("task_success", lambda x: x.mean() * 100),
    average_satisfaction=("satisfaction_rating", "mean"),
    estimated_cost_usd=("estimated_cost_usd", "sum")
).round(2).reset_index()
monthly.to_csv(OUT / "monthly_summary.csv", index=False)

# Simple charts saved as PNG files
charts = [
    ("ai_tool", "Sessions by AI Tool", "AI tool", "sessions_by_tool.png"),
    ("use_case", "Sessions by Use Case", "Use case", "sessions_by_use_case.png"),
    ("prompt_category", "Sessions by Prompt Category", "Prompt category", "sessions_by_prompt_category.png"),
]
for col, title, xlabel, filename in charts:
    counts = df[col].value_counts().sort_values(ascending=False)
    ax = counts.plot(kind="bar")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Number of sessions")
    plt.tight_layout()
    plt.savefig(OUT / filename, dpi=160)
    plt.close()

monthly.set_index("month")["sessions"].plot(kind="line", marker="o")
plt.title("Monthly AI Usage Sessions")
plt.xlabel("Month")
plt.ylabel("Number of sessions")
plt.tight_layout()
plt.savefig(OUT / "monthly_usage.png", dpi=160)
plt.close()

print(f"\nDone. Summary tables and charts saved in: {OUT}")
