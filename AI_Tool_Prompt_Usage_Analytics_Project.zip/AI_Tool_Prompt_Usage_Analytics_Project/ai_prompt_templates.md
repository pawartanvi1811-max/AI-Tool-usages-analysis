# AI Prompt Templates for the Project

Use these prompts with your AI assistant. Replace bracketed text with your own results. Verify calculations yourself.

## Prompt 1 — Explain the dataset
“I am doing an AI Tool / Prompt Usage Analytics project. Explain the meaning of these columns in beginner-friendly language: [paste column names]. Identify which columns are categorical, numerical, dates, and target/outcome variables. Do not invent facts not present in the dataset.”

## Prompt 2 — Data cleaning plan
“Create a data-cleaning checklist for this CSV: [describe columns and any issues found]. Include checks for duplicates, missing values, data types, impossible values, and outliers. Explain why each check matters. Do not delete rows without giving a reason.”

## Prompt 3 — KPI formulas
“Help me calculate total sessions, task success rate, average satisfaction, average response time, total estimated cost, retry rate, and cost per successful session from my dataset. Give Excel formulas and explain the denominator for each metric.”

## Prompt 4 — Exploratory analysis
“Using only these summary tables [paste tables], identify the strongest descriptive patterns in AI tool usage, use cases, prompt categories, success, satisfaction, latency, retries, and estimated cost. Separate observations from possible explanations and do not claim causation.”

## Prompt 5 — Dashboard design
“Suggest a Power BI dashboard layout for AI Tool / Prompt Usage Analytics. Include KPI cards, chart type, fields, slicers, chart titles, and accessibility tips. Dataset columns: [paste column names].”

## Prompt 6 — Write evidence-based insights
“Turn these verified results into 5 concise project insights. For each, state the observation, numeric evidence, business implication, and recommendation. Do not add any numbers not included in my results: [paste results].”

## Prompt 7 — Report review
“Review this project report against a student data analytics rubric. Check objective alignment, metric definitions, chart interpretation, evidence, limitations, ethics, and recommendations. Flag unsupported claims rather than silently rewriting them: [paste report].”

## Prompt 8 — Optional predictive extension
“Explain whether predicting `task_success` is appropriate for this dataset. Identify potential leakage, suitable train/test split, baseline model, evaluation metrics, fairness and privacy limitations. Keep this as an optional extension; the core project is descriptive analytics.”
